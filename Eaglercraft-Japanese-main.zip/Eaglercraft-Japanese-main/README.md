# EaglerCraft 1.8 日本語版
[ここ](https://u5kun.github.io/Eaglercraft-Japanese/) でプレイできます。ダウンロードは不要。日本語です。
<br>
ネタで[パノラマ](https://ja.minecraft.wiki/w/%E3%83%91%E3%83%8E%E3%83%A9%E3%83%9E)とメインメニューのBGMをソ連仕様にしています。
# U5KUNからの一言
翻訳のほとんどは、本物のMinecraft Java Editionのものをそのまま使用しました。
<br>
中継サーバーやボイスチャットなどに関連するEaglerCraftにしかないテキストは、私が翻訳しました。
